package com.asshead.SpringBootMybatis.controller;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.asshead.SpringBootMybatis.entity.User;
import com.asshead.SpringBootMybatis.service.UserService;

@Controller
public class UserController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserService userService;

	User user = new User();

	@RequestMapping(value = "/login")
	public String login() {
		return "login";
	}
	
	@RequestMapping(value = "/find")
	public String find() {
		return "find";
	}

	@RequestMapping(value = "/dologin")
	public String dologin(User user, Model model) {
		User userd = userService.selectUser(user);

		try {
			if (userd == null) {
				model.addAttribute("msg", "用户名或者密码错误！！");
				logger.info("用户名或者密码错误！！");
				return "fail";

			} else {
				model.addAttribute("msg", "登录成功！！！");
				logger.info("登录成功！！！");
				return "success";
			}
		} catch (Exception e) {
			logger.error("登录异常，用户名：{}，密码：{}",user.getUserName(),user.getPassword());
			throw e;
		}

	}

	@RequestMapping(value = "/register")
	public String register() {
		System.out.println("跳往 register");
		return "register";
	}


	@RequestMapping(value = "/registerdo")
	public String createUser(HttpServletRequest request, Model model) {
		String name = request.getParameter("user_id");
		String password = request.getParameter("password");

		user.setUserName(name);
		user.setPassword(password);
		try{
			userService.insert(user);
			model.addAttribute("msg", "注册成功");
			logger.info("注册成功");
			return "yes";
		}catch (Exception e) {
			logger.error("注册异常，用户名：{}，密码：{}",user.getUserName(),user.getPassword());
			throw e;
		}
		
		
		
	}
	
	@RequestMapping(value = "/dofind")
	public String selectSex(HttpServletRequest request, Model model) {
		
		
		String gender = request.getParameter("keyword");
		
		userService.selectSex(gender);
		model.addAttribute("msg","成功查询");
		return "find";
	}

	/*@RequestMapping(value = "/hello")
	public String hello() {
		String username = "tony";
		String occupation = "hairdresser";
		logger.info("首页");
		logger.error("抛出错误！！");
		logger.debug("内部测试！！");
		logger.info("billing  is  hhhh");
		System.setProperty("logback.skipJansi", "true");
		// logger.info("the message is " + msg + " from " +
		// somebody);//不建议使用这种，这段字符串的拼接操作会影响性能
		logger.info("the {} is a {}", username, occupation);// 建议使用占位符的写法
		return "hello";
	}*/

}
