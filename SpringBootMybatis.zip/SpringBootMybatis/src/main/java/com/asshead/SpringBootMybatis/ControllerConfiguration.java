package com.asshead.SpringBootMybatis;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ControllerConfiguration {
	
private static  final  Logger  LOGGER =  LoggerFactory.getLogger("com.asshead.SpringBootMybatis.controller");
	
	public void testIndex() {
		System.out.println("");
	}

}
