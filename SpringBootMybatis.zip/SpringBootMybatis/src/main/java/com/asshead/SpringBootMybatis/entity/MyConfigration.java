package com.asshead.SpringBootMybatis.entity;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.asshead.SpringBootMybatis.filter.AssheadFilter;
import com.asshead.SpringBootMybatis.interceptor.MyInterceptor;
import com.asshead.SpringBootMybatis.listener.MyListener;

public class MyConfigration implements WebMvcConfigurer{
	
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new MyInterceptor()).addPathPatterns("/dologin");
		registry.addInterceptor(new MyInterceptor()).addPathPatterns("/registerdo");
	}
	
	
	
	
	
	@Bean
	public FilterRegistrationBean  filterRegister() {
		FilterRegistrationBean filterBean = new FilterRegistrationBean();
		filterBean.setFilter(new AssheadFilter());
		filterBean.addUrlPatterns("/*");
		return filterBean;
	}
	
	@Bean
	public ServletListenerRegistrationBean registrationBean() {
		ServletListenerRegistrationBean  registrationBean  = new ServletListenerRegistrationBean();
		registrationBean.setListener(new MyListener());
		System.out.println("");
		return registrationBean;
	}

}
