package com.asshead.SpringBootMybatis.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.asshead.SpringBootMybatis.mapper.UserMapper;
import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;
import com.asshead.SpringBootMybatis.entity.User;


@Service
public class UserService {
	@Autowired
	private UserMapper userMapper;
	
	public User selectUser(User user){
		return  userMapper.selectUser(user.getUserName(), user.getPassword());
	}

	
	public User insert(User user){
		boolean result = true;
		User exitNickname = userMapper.selectUser(user.getUserName(), user.getPassword());
		if(exitNickname == null){
			userMapper.insert(user);
		}else{
			result = false;
		}
		return user;
		
	}
	
	
	public void selectSex(String gender){
		String sex = userMapper.selectSex(gender);
	}
}
